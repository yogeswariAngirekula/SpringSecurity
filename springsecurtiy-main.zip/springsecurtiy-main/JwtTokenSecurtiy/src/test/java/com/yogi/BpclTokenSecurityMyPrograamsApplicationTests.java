package com.yogi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpclTokenSecurityMyPrograamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
